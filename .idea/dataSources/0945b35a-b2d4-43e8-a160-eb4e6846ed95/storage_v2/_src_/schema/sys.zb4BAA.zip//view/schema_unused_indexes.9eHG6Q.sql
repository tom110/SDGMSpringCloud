CREATE VIEW schema_unused_indexes AS
  SELECT
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA` AS `object_schema`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`   AS `object_name`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME`    AS `index_name`
  FROM `performance_schema`.`table_io_waits_summary_by_index_usage`
  WHERE ((`performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME` IS NOT NULL) AND
         (`performance_schema`.`table_io_waits_summary_by_index_usage`.`COUNT_STAR` = 0) AND
         (`performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA` <> 'mysql') AND
         (`performance_schema`.`table_io_waits_summary_by_index_usage`.`INDEX_NAME` <> 'PRIMARY'))
  ORDER BY `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_SCHEMA`,
    `performance_schema`.`table_io_waits_summary_by_index_usage`.`OBJECT_NAME`;

