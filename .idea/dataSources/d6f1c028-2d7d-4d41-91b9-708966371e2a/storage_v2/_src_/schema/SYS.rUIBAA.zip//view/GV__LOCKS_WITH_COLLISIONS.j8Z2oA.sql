CREATE VIEW GV_$LOCKS_WITH_COLLISIONS AS
  select "INST_ID","LOCK_ELEMENT_ADDR" from gv$locks_with_collisions
/

