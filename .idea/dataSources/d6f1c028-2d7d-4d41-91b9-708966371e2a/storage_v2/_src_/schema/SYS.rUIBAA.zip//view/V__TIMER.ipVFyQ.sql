CREATE VIEW V_$TIMER AS
  select "HSECS" from v$timer
/

