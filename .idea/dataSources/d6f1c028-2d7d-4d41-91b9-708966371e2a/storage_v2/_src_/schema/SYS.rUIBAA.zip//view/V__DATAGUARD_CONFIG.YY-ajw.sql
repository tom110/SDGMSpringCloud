CREATE VIEW V_$DATAGUARD_CONFIG AS
  select "DB_UNIQUE_NAME" from v$dataguard_config
/

