CREATE VIEW V_$RMAN_CONFIGURATION AS
  select "CONF#","NAME","VALUE" from v$rman_configuration
/

