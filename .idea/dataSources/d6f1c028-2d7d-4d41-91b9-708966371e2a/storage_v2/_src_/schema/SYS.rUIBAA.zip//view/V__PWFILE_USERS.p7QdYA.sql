CREATE VIEW V_$PWFILE_USERS AS
  select "USERNAME","SYSDBA","SYSOPER","SYSASM" from v$pwfile_users
/

