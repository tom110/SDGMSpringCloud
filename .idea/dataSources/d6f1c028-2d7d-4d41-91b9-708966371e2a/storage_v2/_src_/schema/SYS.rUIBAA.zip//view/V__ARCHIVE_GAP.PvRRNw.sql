CREATE VIEW V_$ARCHIVE_GAP AS
  select "THREAD#","LOW_SEQUENCE#","HIGH_SEQUENCE#" from v$archive_gap
/

