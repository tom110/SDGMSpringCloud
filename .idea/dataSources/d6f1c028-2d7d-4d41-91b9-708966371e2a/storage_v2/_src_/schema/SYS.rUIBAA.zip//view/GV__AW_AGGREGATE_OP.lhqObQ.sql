CREATE VIEW GV_$AW_AGGREGATE_OP AS
  select "INST_ID","NAME","LONGNAME","DEFAULT_WEIGHT" from gv$aw_aggregate_op
/

