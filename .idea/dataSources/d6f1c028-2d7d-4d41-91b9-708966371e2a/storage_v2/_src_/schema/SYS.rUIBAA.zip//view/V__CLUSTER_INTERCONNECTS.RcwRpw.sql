CREATE VIEW V_$CLUSTER_INTERCONNECTS AS
  select "NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from v$cluster_interconnects
/

