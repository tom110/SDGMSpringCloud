CREATE VIEW GV_$LATCHNAME AS
  select "INST_ID","LATCH#","NAME","HASH" from gv$latchname
/

