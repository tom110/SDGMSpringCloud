CREATE VIEW GV_$CONFIGURED_INTERCONNECTS AS
  select "INST_ID","NAME","IP_ADDRESS","IS_PUBLIC","SOURCE" from gv$configured_interconnects
/

