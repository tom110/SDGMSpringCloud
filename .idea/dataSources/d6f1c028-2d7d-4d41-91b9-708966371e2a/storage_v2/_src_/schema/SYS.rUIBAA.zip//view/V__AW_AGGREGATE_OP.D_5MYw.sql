CREATE VIEW V_$AW_AGGREGATE_OP AS
  select "NAME","LONGNAME","DEFAULT_WEIGHT" from v$aw_aggregate_op
/

