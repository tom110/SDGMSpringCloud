CREATE VIEW V_$SYSTEM_CURSOR_CACHE AS
  select "OPENS","HITS","HIT_RATIO" from v$system_cursor_cache
/

