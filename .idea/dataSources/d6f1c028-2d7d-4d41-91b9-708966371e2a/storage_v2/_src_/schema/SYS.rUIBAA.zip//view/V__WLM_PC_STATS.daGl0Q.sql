CREATE VIEW V_$WLM_PC_STATS AS
  select "PC_NAME_HASH","PC_NAME","STAT_ID","STAT_NAME","VALUE" from v$wlm_pc_stats
/

