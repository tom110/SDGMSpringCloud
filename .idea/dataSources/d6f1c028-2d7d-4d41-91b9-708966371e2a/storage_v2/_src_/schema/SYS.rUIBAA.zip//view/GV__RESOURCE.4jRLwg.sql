CREATE VIEW GV_$RESOURCE AS
  select "INST_ID","ADDR","TYPE","ID1","ID2" from gv$resource
/

