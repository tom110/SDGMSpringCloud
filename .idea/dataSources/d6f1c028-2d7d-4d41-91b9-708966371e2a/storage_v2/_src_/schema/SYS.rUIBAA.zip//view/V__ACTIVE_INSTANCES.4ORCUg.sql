CREATE VIEW V_$ACTIVE_INSTANCES AS
  select "INST_NUMBER","INST_NAME" from v$active_instances
/

