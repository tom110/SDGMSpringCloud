CREATE VIEW V_$SYSSTAT AS
  select "STATISTIC#","NAME","CLASS","VALUE","STAT_ID" from v$sysstat
/

