CREATE VIEW GV_$GC_ELEMENTS_W_COLLISIONS AS
  select "INST_ID","GC_ELEMENT_ADDR" from gv$gc_elements_with_collisions
/

