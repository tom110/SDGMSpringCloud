CREATE VIEW GV_$SQLFN_ARG_METADATA AS
  select "INST_ID","FUNC_ID","ARGNUM","DATATYPE","DESCR" from gv$sqlfn_arg_metadata
/

