CREATE VIEW GV_$DLM_MISC AS
  select "INST_ID","STATISTIC#","NAME","VALUE" from gv$dlm_misc
/

