CREATE VIEW GV_$ENABLEDPRIVS AS
  select "INST_ID","PRIV_NUMBER" from gv$enabledprivs
/

