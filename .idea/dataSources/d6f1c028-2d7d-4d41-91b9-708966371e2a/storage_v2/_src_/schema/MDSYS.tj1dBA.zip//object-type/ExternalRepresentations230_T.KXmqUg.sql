CREATE TYPE         "ExternalRepresentations230_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GML" "SharedValueType215_T","CityGML" "SharedValueType215_T","KML" "SharedValueType215_T","X3D" "SharedValueType215_T","BIM" "SharedValueType215_T")FINAL INSTANTIABLE
/

