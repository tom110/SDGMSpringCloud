CREATE type SDO_TOPO_OBJECT
as Object (topo_id number, topo_type number)
/

