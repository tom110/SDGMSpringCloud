CREATE TYPE         "Style3dType214_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Color" "SharedValueType215_T","Texture" "TextureType216_T","ModelStyle" "FeatureReferenceType205_T","Normals" "Normals217_T")NOT FINAL INSTANTIABLE
/

