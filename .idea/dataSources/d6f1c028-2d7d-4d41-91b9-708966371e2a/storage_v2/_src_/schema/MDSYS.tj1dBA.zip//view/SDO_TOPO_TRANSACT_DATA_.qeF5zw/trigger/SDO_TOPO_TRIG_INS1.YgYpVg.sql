-- Cannot generate trigger SDO_TOPO_TRIG_INS1: the table is unknown
/

