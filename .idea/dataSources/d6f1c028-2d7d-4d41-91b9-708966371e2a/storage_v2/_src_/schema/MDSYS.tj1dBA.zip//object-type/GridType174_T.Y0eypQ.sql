CREATE TYPE         "GridType174_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","GridProperties" "GridPropertiesType173_T","GridData" "GridDataType162_T","HierarchyParticipation" "HierarchyParticipation175_T")NOT FINAL INSTANTIABLE
/

