CREATE TYPE ST_GEOMETRY_ARRAY
                                      
AS VARRAY(1048576) OF ST_GEOMETRY
/

