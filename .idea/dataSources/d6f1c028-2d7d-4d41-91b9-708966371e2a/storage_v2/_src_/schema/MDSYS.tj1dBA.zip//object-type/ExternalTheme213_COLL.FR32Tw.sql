CREATE TYPE         "ExternalTheme213_COLL" AS VARRAY(2147483647) OF "ExternalTheme211_T"
/

