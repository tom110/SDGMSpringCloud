CREATE TRIGGER "Vis3DConfig233_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "Vis3DConfig233_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Vis3DConfig233_TAB', :old.sys_nc_oid$, 'AB9F0D8F32AF7A52E040E50A194E5521' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Vis3DConfig233_TAB', :old.sys_nc_oid$, 'AB9F0D8F32AF7A52E040E50A194E5521', user ); END IF; END;
/

