CREATE TYPE         "ViewFrame3dType220_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","SceneName" VARCHAR2(4000 CHAR),"ViewPoint3d" "ViewPoint3dType221_T","DefaultStyle" "Style3dType214_T")NOT FINAL INSTANTIABLE
/

