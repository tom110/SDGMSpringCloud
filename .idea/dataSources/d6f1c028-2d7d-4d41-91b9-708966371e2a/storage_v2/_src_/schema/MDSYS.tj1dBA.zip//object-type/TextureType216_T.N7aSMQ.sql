CREATE TYPE         "TextureType216_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","TextureBLOB" "SharedValueType215_T","TextureCoordinates" "SharedValueType215_T")NOT FINAL INSTANTIABLE
/

