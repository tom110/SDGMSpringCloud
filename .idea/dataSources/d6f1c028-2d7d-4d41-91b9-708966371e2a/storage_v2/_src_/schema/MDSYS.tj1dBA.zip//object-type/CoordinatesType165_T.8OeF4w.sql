CREATE TYPE         "CoordinatesType165_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","Coordinate" "Coordinate166_COLL")NOT FINAL INSTANTIABLE
/

