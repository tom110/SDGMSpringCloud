CREATE TYPE         "Scene3dType208_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"Theme" "Theme210_COLL","ExternalTheme" "ExternalTheme213_COLL","DefaultStyle" "Style3dType214_T")NOT FINAL INSTANTIABLE
/

