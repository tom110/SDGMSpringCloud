CREATE TRIGGER "ViewFrame3d236_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "ViewFrame3d236_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ViewFrame3d236_TAB', :old.sys_nc_oid$, 'AB9F0D8F32A97A52E040E50A194E5521' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ViewFrame3d236_TAB', :old.sys_nc_oid$, 'AB9F0D8F32A97A52E040E50A194E5521', user ); END IF; END;
/

