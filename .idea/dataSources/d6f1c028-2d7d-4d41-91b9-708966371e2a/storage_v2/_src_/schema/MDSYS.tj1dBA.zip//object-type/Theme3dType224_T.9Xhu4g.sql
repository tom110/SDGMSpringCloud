CREATE TYPE         "Theme3dType224_T" AS OBJECT ("SYS_XDBPD$" "XDB"."XDB$RAW_LIST_T","srid" NUMBER(38),"LOD" "LOD225_T","DefaultStyle" "Style3dType214_T","Tiling" "Tiling226_T","hidden_info" "hidden_info227_T","ExternalRepresentations" "ExternalRepresentations230_T")NOT FINAL INSTANTIABLE
/

