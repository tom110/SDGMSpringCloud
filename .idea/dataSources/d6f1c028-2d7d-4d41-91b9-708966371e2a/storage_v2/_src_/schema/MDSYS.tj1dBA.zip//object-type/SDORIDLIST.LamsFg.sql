CREATE type sdoridlist as varray(1048576) of varchar2(24)
/

