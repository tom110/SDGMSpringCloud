CREATE TRIGGER "Theme3d238_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "Theme3d238_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','Theme3d238_TAB', :old.sys_nc_oid$, 'AB9F0D8F32A27A52E040E50A194E5521' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','Theme3d238_TAB', :old.sys_nc_oid$, 'AB9F0D8F32A27A52E040E50A194E5521', user ); END IF; END;
/

