-- Cannot generate trigger SDO_ANNOT_TRIG_INS1: the table is unknown
/

