-- Cannot generate trigger SDO_CRS_INSERT_TRIGGER: the table is unknown
/

