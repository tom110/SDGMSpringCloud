CREATE TYPE ST_CIRCULARSTRING
                                       UNDER ST_CURVE (
  CONSTRUCTOR FUNCTION ST_CIRCULARSTRING(apointarray ST_Point_Array)
           RETURN SELF AS RESULT,
  CONSTRUCTOR FUNCTION ST_CIRCULARSTRING(apointarray ST_Point_Array,
            asrid INTEGER) RETURN SELF AS RESULT,

  MEMBER FUNCTION ST_Points(apointarray ST_Point_Array)
           RETURN ST_CircularString)
/

