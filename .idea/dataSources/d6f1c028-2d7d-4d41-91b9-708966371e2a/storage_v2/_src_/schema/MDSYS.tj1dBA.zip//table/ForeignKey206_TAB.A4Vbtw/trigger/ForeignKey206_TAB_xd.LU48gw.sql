CREATE TRIGGER "ForeignKey206_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "ForeignKey206_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('MDSYS','ForeignKey206_TAB', :old.sys_nc_oid$, 'AB9F0D8F32B27A52E040E50A194E5521' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('MDSYS','ForeignKey206_TAB', :old.sys_nc_oid$, 'AB9F0D8F32B27A52E040E50A194E5521', user ); END IF; END;
/

