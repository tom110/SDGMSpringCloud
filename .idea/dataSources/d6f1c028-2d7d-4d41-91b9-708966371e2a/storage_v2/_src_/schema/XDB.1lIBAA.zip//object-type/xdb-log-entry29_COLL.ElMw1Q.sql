CREATE TYPE       "xdb-log-entry29_COLL" AS VARRAY(2147483647) OF "xdb-log-entry-type27_T"
/

