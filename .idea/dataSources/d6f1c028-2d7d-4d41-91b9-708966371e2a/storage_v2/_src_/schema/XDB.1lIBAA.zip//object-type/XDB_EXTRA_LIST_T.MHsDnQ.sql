CREATE type     xdb$extra_list_t                                        as varray(65535) of varchar2(2000);
/

