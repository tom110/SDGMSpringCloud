CREATE type       SYS_PLSQL_14938_DUMMY_1 as table of number;
/

