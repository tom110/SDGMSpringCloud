CREATE type     xdb$import_list_t                                        as varray(65535) of xdb.xdb$import_t;
/

