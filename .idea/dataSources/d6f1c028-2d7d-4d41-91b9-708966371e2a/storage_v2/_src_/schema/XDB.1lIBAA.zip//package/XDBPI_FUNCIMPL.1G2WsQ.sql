CREATE package     xdbpi_funcimpl as
  function noop_func(res sys.xmltype) return number;
end;
/

