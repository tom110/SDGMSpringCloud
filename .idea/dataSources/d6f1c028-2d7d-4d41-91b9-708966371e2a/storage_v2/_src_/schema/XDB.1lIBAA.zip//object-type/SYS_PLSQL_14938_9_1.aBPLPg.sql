CREATE type       SYS_PLSQL_14938_9_1 as table of VARCHAR2(4000);
/

