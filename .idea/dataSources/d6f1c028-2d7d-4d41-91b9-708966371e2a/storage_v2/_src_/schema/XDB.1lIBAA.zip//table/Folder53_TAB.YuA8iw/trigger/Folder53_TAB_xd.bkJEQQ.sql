CREATE TRIGGER "Folder53_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "Folder53_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','Folder53_TAB', :old.sys_nc_oid$, 'AB9F072B3F305159E040E50A194E4ED6' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','Folder53_TAB', :old.sys_nc_oid$, 'AB9F072B3F305159E040E50A194E4ED6', user ); END IF; END;
/

