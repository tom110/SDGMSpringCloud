CREATE TYPE       "ftp-log-entry37_COLL" AS VARRAY(2147483647) OF "ftp-log-entry-type34_T"
/

