CREATE TYPE       "include65_COLL" AS VARRAY(2147483647) OF "includeType58_T"
/

