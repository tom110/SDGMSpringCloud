CREATE TRIGGER "privilege155_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "privilege155_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','privilege155_TAB', :old.sys_nc_oid$, 'AB9F072B441D5159E040E50A194E4ED6' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','privilege155_TAB', :old.sys_nc_oid$, 'AB9F072B441D5159E040E50A194E4ED6', user ); END IF; END;
/

