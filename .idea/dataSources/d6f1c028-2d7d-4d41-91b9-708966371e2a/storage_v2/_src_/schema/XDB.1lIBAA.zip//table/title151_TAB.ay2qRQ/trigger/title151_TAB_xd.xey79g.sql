CREATE TRIGGER "title151_TAB$xd"
  AFTER UPDATE OR DELETE
  ON "title151_TAB"
  FOR EACH ROW
  BEGIN  IF (deleting) THEN xdb.xdb_pitrig_pkg.pitrig_del('XDB','title151_TAB', :old.sys_nc_oid$, 'AB9F072B441F5159E040E50A194E4ED6' ); END IF;   IF (updating) THEN xdb.xdb_pitrig_pkg.pitrig_upd('XDB','title151_TAB', :old.sys_nc_oid$, 'AB9F072B441F5159E040E50A194E4ED6', user ); END IF; END;
/

