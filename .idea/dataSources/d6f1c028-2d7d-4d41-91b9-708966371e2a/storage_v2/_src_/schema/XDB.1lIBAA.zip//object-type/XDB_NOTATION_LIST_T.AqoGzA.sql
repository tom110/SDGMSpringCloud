CREATE type     xdb$notation_list_t
                                      
as varray(1000) of xdb.xdb$notation_t
/

