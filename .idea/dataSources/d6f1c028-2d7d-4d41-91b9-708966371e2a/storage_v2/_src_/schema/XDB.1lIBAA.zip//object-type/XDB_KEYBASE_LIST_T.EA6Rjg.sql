CREATE type     xdb$keybase_list_t
                                      
as varray(1000) of xdb.xdb$keybase_t
/

