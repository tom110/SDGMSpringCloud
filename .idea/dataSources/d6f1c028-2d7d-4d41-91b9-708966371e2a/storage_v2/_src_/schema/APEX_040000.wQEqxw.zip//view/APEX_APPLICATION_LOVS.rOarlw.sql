CREATE VIEW APEX_APPLICATION_LOVS AS
  select
    w.short_name                     workspace,
    f.ID                             application_id,
    f.NAME                           application_name,
    l.LOV_NAME                       list_of_values_name,
    --
    decode(substr(l.lov_query,1,1),
    '.','Static','Dynamic')          lov_type,
    decode(substr(l.lov_query,1,1),
    '.',null,l.LOV_QUERY)
                                     list_of_values_query,
    (select count(*)
    from wwv_flow_list_of_values_data
    where flow_id = f.id and
          lov_id = l.id)             lov_entries,
    --
    decode(l.REFERENCE_ID,null,'No','Yes')
                                     is_subscribed,
    (select flow_id||'. '||name n
     from wwv_flow_lists_of_values$
     where id = l.reference_id)      subscribed_from,
    --
    l.LAST_UPDATED_BY                last_updated_by,
    l.LAST_UPDATED_ON                last_updated_on,
    l.LOV_COMMENT                    component_comment,
    --
    l.ID                             lov_id,
    l.REFERENCE_ID                   referenced_lov_id,
    --
    l.LOV_NAME
    ||' t='||decode(substr(l.lov_query,1,1),'.','Static','Dynamic')
    ||' q='||decode(substr(l.lov_query,1,1),'.',null,substr(l.LOV_QUERY,1,30)||length(l.LOV_QUERY))
    ||' ref='||decode(l.REFERENCE_ID,null,'No','Yes')
    component_signature
from wwv_flow_lists_of_values$ l,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.id = l.flow_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

