CREATE VIEW APEX_APPLICATION_PAGE_PROC AS
  select
     w.short_name                   workspace,
     p.flow_id                      application_id,
     f.name                         application_name,
     p.id                           page_id,
     p.name                         page_name,
     --
     pr.process_name                process_name,
     pr.process_sequence            execution_sequence,
     --
     decode(pr.process_point,
       'RETURN_VALUE','DISPLAY_VALUE',
       'AFTER_AUTHENTICATION','On New Instance After Authentication',
       'BEFORE_HEADER','On Load - Before Header',
       'AFTER_HEADER','On Load - After Header',
       'BEFORE_BOX_BODY','On Load - Before Regions',
       'AFTER_BOX_BODY','On Load - After Regions',
       'BEFORE_FOOTER','On Load - Before Footer',
       'AFTER_FOOTER','On Load - After Footer',
       'ON_SUBMIT_BEFORE_COMPUTATION','On Submit - Before Computations and Validations ',
       'AFTER_SUBMIT','On Submit - After Computations and Validations',
       'ON_DEMAND','On Demand - Run this process when requested by AJAX',
       'AFTER_ERROR_HEADER','On Error - After Header',
       'BEFORE_ERROR_FOOTER','On Error - Before Footer',
       'BEFORE_SHOW_ITEMS','Deprecated - Before Showing page items',
       'AFTER_SHOW_ITEMS','Deprecated - After showing page items',
       pr.process_point)            process_point,
     pr.process_point               process_point_code,
     --
     case substr(pr.process_type, 1, 7)
       when 'NATIVE_' then
           ( select display_name from wwv_flow_plugins where flow_id = 4411 and plugin_type = 'PROCESS TYPE' and name = substr(pr.process_type, 8) )
       when 'PLUGIN_' then
           ( select display_name from wwv_flow_plugins where flow_id = p.flow_id and plugin_type = 'PROCESS TYPE' and name = substr(pr.process_type, 8) )
       else
           decode(pr.process_type,
               'RETURN_VALUE','DISPLAY_VALUE',
               'GET_NEXT_OR_PREV_PK','Get Next or Previous Primary Key Value',
               'INITIALIZE_PAGINATION_FOR_ALL_PAGES','Reset Pagination For All Pages',
               'INITIALIZE_PAGE_PAGINATION','Reset Pagination For Page(s) (PageID,PageID,PageID)',
               'CLEAR_CACHE_CURRENT_FLOW','Clear Cache For Current Application (removes all session state for current application)',
               'CLEAR_CACHE_FOR_FLOWS','Clear Cache For Applications (removes all session state for listed applications)',
               'ADD_ROWS_TO_TABULAR_FORM','Add rows to tabular form',
               'WEB_SERVICE','Web Service',
               'CLOSE_WINDOW','Close popup window',
               'PLSQL','PL/SQL anonymous block',
               'PLSQL_DBMS_JOB','PL/SQL DBMS JOB (runs anonymous block asynchronously)',
               'RESET_PAGINATION','Reset Pagination',
               'CLEAR_CACHE_FOR_PAGES','Clear Cache for all Items on Pages (PageID,PageID,PageID)',
               'CLEAR_CACHE_FOR_ITEMS','Clear Cache for Items (ITEM,ITEM,ITEM)',
               'DML_FETCH_ROW','Automated Row Fetch',
               'DML_PROCESS_ROW','Automatic Row Processing (DML)',
               'SET_PREFERENCE_TO_ITEM_VALUE','Set Preference to value of Item',
               'SET_PREFERENCE_TO_ITEM_VALUE_IF_ITEM_NOT_NULL','Set Preference to value of Item if item is not null (PreferenceName:ITEM)',
               'MULTI_ROW_UPDATE','Multi Row Update',
               'RESET_SESSION_STATE','Clear Cache For Current Session (removes all state for current session)',
               'RESET_USER_PREFERENCES','Reset Preferences (remove all preferences for current user)',
               'INITIALIZE_ALL_PAGE_ITEMS','Initialize all page items',
               'ON_DEMAND','On Demand - Run an on-demand application process',
               'MULTI_ROW_DELETE','Multi Row Delete',
               pr.process_type)
     end                          process_type,
     pr.process_type              process_type_code,
     --pr.ITEM_NAME,
       case
         when pr.process_type = 'GET_NEXT_OR_PREV_PK' /* stores the where clause in PROCESS_SOURCE instead of RUNTIME_WHERE_CLAUSE */
          and instr(pr.process_sql_clob, ':', 1, 13) > 0
         then
             replace(to_char(substr(pr.process_sql_clob, instr(pr.process_sql_clob, ':', 1, 13)+1, 4000)), '<cbchoesc>', ':')
         else
             pr.runtime_where_clause
       end                          runtime_where_clause,
     pr.process_sql_clob            process_source,
     pr.attribute_01,
     pr.attribute_02,
     pr.attribute_03,
     pr.attribute_04,
     pr.attribute_05,
     pr.attribute_06,
     pr.attribute_07,
     pr.attribute_08,
     pr.attribute_09,
     pr.attribute_10,
     pr.process_error_message       process_error_message,
     --
     (select button_name
      from wwv_flow_step_buttons
      where id = pr.process_when_button_id
      union
      select name
      from wwv_flow_step_items
      where id = pr.process_when_button_id)
                                    when_button_pressed,
     pr.process_when_button_id      when_button_pressed_id,
     --
     nvl((select r from apex_standard_conditions where d = pr.process_when_type),pr.process_when_type)
                                    condition_type,
     pr.process_when_type           condition_type_code,
     pr.process_when                condition_expression1,
     pr.process_when2               condition_expression2,
     --pr.PROCESS_WHEN_TYPE2,
     --
     decode(pr.process_is_stateful_y_n,
       'Y','Once Per Session or When Reset',
       'N','Once Per Page Visit (default)',
       pr.PROCESS_IS_STATEFUL_Y_N)  run_process,
     --
     pr.return_key_into_item1       return_key_into_item_1,
     pr.return_key_into_item2       return_key_into_item_2,
     pr.process_success_message     success_message,
     --
     (select case when pr.required_patch > 0 then patch_name else '{Not '||patch_name||'}' end patch_name
     from wwv_flow_patches
     where id=abs(pr.required_patch))    build_option,
     --
     decode(substr(pr.security_scheme,1,1),'!','Not ')||
     nvl((select name
      from   wwv_flow_security_schemes
      where  to_char(id) = ltrim(pr.security_scheme,'!')
      and    flow_id = f.id),
      pr.security_scheme)           authorization_scheme,
     pr.security_scheme             authorization_scheme_id,
     --
     pr.last_updated_by             last_updated_by,
     pr.last_updated_on             last_updated_on,
     pr.process_comment             component_comment,
     pr.id                          process_id,
     --
     lpad(pr.PROCESS_SEQUENCE,5,'00000')
     ||',point='||decode(pr.PROCESS_POINT,
       'RETURN_VALUE','DISPLAY_VALUE',
       'AFTER_AUTHENTICATION','On New Instance After Authentication',
       'BEFORE_HEADER','On Load - Before Header',
       'AFTER_HEADER','On Load - After Header',
       'BEFORE_BOX_BODY','On Load - Before Regions',
       'AFTER_BOX_BODY','On Load - After Regions',
       'BEFORE_FOOTER','On Load - Before Footer',
       'AFTER_FOOTER','On Load - After Footer',
       'ON_SUBMIT_BEFORE_COMPUTATION','On Submit - Before Computations and Validations ',
       'AFTER_SUBMIT','On Submit - After Computations and Validations',
       'ON_DEMAND','On Demand - Run this process when requested by AJAX',
       'AFTER_ERROR_HEADER','On Error - After Header',
       'BEFORE_ERROR_FOOTER','On Error - Before Footer',
       'BEFORE_SHOW_ITEMS','Deprecated - Before Showing page items',
       'AFTER_SHOW_ITEMS','Deprecated - After showing page items',
       pr.PROCESS_POINT)
     ||',type='||decode(pr.PROCESS_TYPE,
       'RETURN_VALUE','DISPLAY_VALUE',
       'GET_NEXT_OR_PREV_PK','Get Next or Previous Primary Key Value',
       'INITIALIZE_PAGINATION_FOR_ALL_PAGES','Reset Pagination For All Pages',
       'INITIALIZE_PAGE_PAGINATION','Reset Pagination For Page(s) (PageID,PageID,PageID)',
       'CLEAR_CACHE_CURRENT_FLOW','Clear Cache For Current Application (removes all session state for current application)',
       'CLEAR_CACHE_FOR_FLOWS','Clear Cache For Applications (removes all session state for listed applications)',
       'ADD_ROWS_TO_TABULAR_FORM','Add rows to tabular form',
       'WEB_SERVICE','Web Service',
       'CLOSE_WINDOW','Close popup window',
       'PLSQL','PL/SQL anonymous block',
       'PLSQL_DBMS_JOB','PL/SQL DBMS JOB (runs anonymous block asynchronously)',
       'RESET_PAGINATION','Reset Pagination',
       'CLEAR_CACHE_FOR_PAGES','Clear Cache for all Items on Pages (PageID,PageID,PageID)',
       'CLEAR_CACHE_FOR_ITEMS','Clear Cache for Items (ITEM,ITEM,ITEM)',
       'DML_FETCH_ROW','Automated Row Fetch',
       'DML_PROCESS_ROW','Automatic Row Processing (DML)',
       'SET_PREFERENCE_TO_ITEM_VALUE','Set Preference to value of Item',
       'SET_PREFERENCE_TO_ITEM_VALUE_IF_ITEM_NOT_NULL','Set Preference to value of Item if item is not null (PreferenceName:ITEM)',
       'MULTI_ROW_UPDATE','Multi Row Update',
       'RESET_SESSION_STATE','Clear Cache For Current Session (removes all state for current session)',
       'RESET_USER_PREFERENCES','Reset Preferences (remove all preferences for current user)',
       'INITIALIZE_ALL_PAGE_ITEMS','Initialize all page items',
       'ON_DEMAND','On Demand - Run an on-demand application process',
       'MULTI_ROW_DELETE','Multi Row Delete',
       pr.PROCESS_TYPE)
       ||',src='||dbms_lob.substr(pr.PROCESS_SQL_CLOB,30,1)||'.'||
       dbms_lob.getlength(pr.PROCESS_SQL_CLOB)
       ||(select ',wbp='||button_name n from wwv_flow_step_buttons where id = pr.PROCESS_WHEN_BUTTON_ID
       union
       select ',wbp='||name n from wwv_flow_step_items where id = pr.PROCESS_WHEN_BUTTON_ID)
       ||decode(pr.PROCESS_ERROR_MESSAGE,null,null,',errm='||
       substr(pr.PROCESS_ERROR_MESSAGE,1,20)||length(pr.PROCESS_ERROR_MESSAGE))
       ||decode(pr.PROCESS_SUCCESS_MESSAGE,null,null,',succm='||
       substr(pr.PROCESS_SUCCESS_MESSAGE,1,20)||length(pr.PROCESS_SUCCESS_MESSAGE))
       ||nvl((select name from wwv_flow_security_schemes where to_char(id) = ltrim(pr.SECURITY_SCHEME,'!') and flow_id = f.id),pr.SECURITY_SCHEME)
       ||',cond='||pr.PROCESS_WHEN_TYPE
       ||substr(pr.PROCESS_WHEN,1,20)||length(pr.PROCESS_WHEN)||'.'
       ||substr(pr.PROCESS_WHEN2,1,20)||length(pr.PROCESS_WHEN2)
       ||(select PATCH_NAME from wwv_flow_patches where id=abs(pr.REQUIRED_PATCH))
       ||decode(pr.PROCESS_IS_STATEFUL_Y_N,'Y','Once Per Session or When Reset','N','Once Per Page Visit (default)',pr.PROCESS_IS_STATEFUL_Y_N)
     ||',key='||pr.RETURN_KEY_INTO_ITEM1||pr.RETURN_KEY_INTO_ITEM1
     component_signature
from wwv_flow_step_processing pr,
     wwv_flow_steps p,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = f.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = p.security_group_id and
      f.security_group_id = pr.security_group_id and
      f.id = p.flow_id and
      f.id = pr.flow_id and
      p.id = pr.flow_step_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

