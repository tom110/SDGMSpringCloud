CREATE TRIGGER WWV_FLOW_PAGE_DA_ACTIONS_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_PAGE_DA_ACTIONS
  FOR EACH ROW
  begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;

    if inserting then
        :new.CREATED_ON := sysdate;
        :new.created_by := nvl(wwv_flow.g_user,user);
    end if;

    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;

    --
    -- last updates
    --
    if not wwv_flow.g_import_in_progress then
        -- for the wwv_flow_page_da_actions table
        :new.last_updated_on := sysdate;
        :new.last_updated_by := nvl(wwv_flow.g_user,user);
        -- for the parent wwv_flow_page_da_events table, we need to exclude when this trigger has fired as a result of
        -- a parent region being deleted. we can pick this up when affected_region_id is set to null and
        -- affected_elements_type is still REGION (as this can't be done directly in the ui)
        if :old.affected_region_id is not null and :new.affected_region_id is null and
           :old.affected_elements_type = 'REGION' and :new.affected_elements_type = 'REGION' then
            -- do nothing
            null;
        else
            -- update the parent
            wwv_flow_audit.g_cascade := true;
            update wwv_flow_page_da_events set
               last_updated_on = sysdate,
               last_updated_by = nvl(wwv_flow.g_user,user)
            where
               id = :new.event_id and
               security_group_id = :new.security_group_id;
            wwv_flow_audit.g_cascade := false;
        end if;
    end if;
end;
/

