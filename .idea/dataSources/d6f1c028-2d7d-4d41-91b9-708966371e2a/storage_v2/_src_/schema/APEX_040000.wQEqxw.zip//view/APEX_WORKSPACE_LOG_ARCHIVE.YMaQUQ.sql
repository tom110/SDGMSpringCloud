CREATE VIEW APEX_WORKSPACE_LOG_ARCHIVE AS
  select
    w.short_name                           workspace,
    l.LOG_DAY,
    l.WORKSPACE_ID,
    l.APPLICATION_ID,
    l.PAGE_EVENTS,
    l.PAGE_VIEWS,
    l.PAGE_ACCEPTS,
    l.PARTIAL_PAGE_VIEWS,
    l.WEBSHEET_VIEWS,
    l.ROWS_FETCHED,
    l.IR_SEARCHES,
    l.DISTINCT_PAGES,
    l.DISTINCT_USERS,
    l.DISTINCT_SESSIONS,
    l.AVERAGE_RENDER_TIME,
    l.MEDIAN_RENDER_TIME,
    l.MAXIMUM_RENDER_TIME,
    l.TOTAL_RENDER_TIME,
    l.ERROR_COUNT,
    l.content_length
from WWV_FLOW_LOG_HISTORY l,
     wwv_flow_companies w,
     (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (l.workspace_id in (select security_group_id from  wwv_flow_company_schemas where schema = user) or
       user in ('SYS','SYSTEM', 'APEX_040000')  or
       d.sgid = l.workspace_id) and
       l.workspace_id = w.PROVISIONING_COMPANY_ID and
      w.PROVISIONING_COMPANY_ID != 0
/

