CREATE VIEW WWV_FLOW_FEATURE_COLS AS
  select 'FEATURE_NAME' cname, wwv_flow_lang.system_message('FEATURE_NAME') cmessage from dual union all
select 'FEATURE_OWNER' cname, wwv_flow_lang.system_message('FEATURE_OWNER') cmessage from dual union all
select 'FOCUS_AREA' cname, wwv_flow_lang.system_message('FOCUS_AREA') cmessage from dual union all
select 'RELEASE ' cname, wwv_flow_lang.system_message('RELEASE ') cmessage from dual union all
select 'FEATURE_DESC' cname, wwv_flow_lang.system_message('FEATURE_DESC') cmessage from dual union all
select 'GLOBALIZATION_IMPACT' cname, wwv_flow_lang.system_message('GLOBALIZATION_IMPACT') cmessage from dual union all
select 'DOC_IMPACT' cname, wwv_flow_lang.system_message('DOC_IMPACT') cmessage from dual union all
select 'TESTING_IMPACT' cname, wwv_flow_lang.system_message('TESTING_IMPACT') cmessage from dual union all
select 'SECURITY_IMPACT' cname, wwv_flow_lang.system_message('SECURITY_IMPACT') cmessage from dual union all
select 'ACCESSIBILITY_IMPACT' cname, wwv_flow_lang.system_message('ACCESSIBILITY_IMPACT') cmessage from dual union all
select 'FEATURE_TAGS' cname, wwv_flow_lang.system_message('FEATURE_TAGS') cmessage from dual union all
select 'FEATURE_PRIORITY' cname, wwv_flow_lang.system_message('FEATURE_PRIORITY') cmessage from dual union all
select 'FEATURE_STATUS' cname, wwv_flow_lang.system_message('FEATURE_STATUS') cmessage from dual union all
select 'APPLICATION_ID' cname, wwv_flow_lang.system_message('APPLICATION_ID') cmessage from dual union all
select 'FEATURE_DESIRABILITY' cname, wwv_flow_lang.system_message('FEATURE_DESIRABILITY') cmessage from dual union all
select 'PARENT_FEATURE_ID' cname, wwv_flow_lang.system_message('PARENT_FEATURE_ID') cmessage from dual union all
select 'DUE_DATE' cname, wwv_flow_lang.system_message('DUE_DATE') cmessage from dual union all
select 'START_DATE' cname, wwv_flow_lang.system_message('START_DATE') cmessage from dual union all
select 'EVENT_ID' cname, wwv_flow_lang.system_message('EVENT_ID') cmessage from dual union all
select 'DOC_STATUS' cname, wwv_flow_lang.system_message('DOC_STATUS') cmessage from dual union all
select 'USER_INTERFACE_IMPACT' cname, wwv_flow_lang.system_message('USER_INTERFACE_IMPACT') cmessage from dual union all
select 'DOC_WRITER' cname, wwv_flow_lang.system_message('DOC_WRITER') cmessage from dual union all
select 'FEATURE_CONTRIBUTOR' cname, wwv_flow_lang.system_message('FEATURE_CONTRIBUTOR') cmessage from dual union all
select 'JUSTIFICATION' cname, wwv_flow_lang.system_message('JUSTIFICATION') cmessage from dual union all
select 'GLOBALIZATION_ASSIGNEE' cname, wwv_flow_lang.system_message('GLOBALIZATION_ASSIGNEE') cmessage from dual union all
select 'USER_INTERFACE_ASSIGNEE' cname, wwv_flow_lang.system_message('USER_INTERFACE_ASSIGNEE') cmessage from dual union all
select 'TESTING_ASSIGNEE' cname, wwv_flow_lang.system_message('TESTING_ASSIGNEE') cmessage from dual union all
select 'SECURITY_ASSIGNEE' cname, wwv_flow_lang.system_message('SECURITY_ASSIGNEE') cmessage from dual union all
select 'ACCESSIBILITY_ASSIGNEE' cname, wwv_flow_lang.system_message('ACCESSIBILITY_ASSIGNEE') cmessage from dual union all
select 'TESTING_STATUS' cname, wwv_flow_lang.system_message('TESTING_STATUS') cmessage from dual union all
select 'MODULE' cname, wwv_flow_lang.system_message('MODULE  ') cmessage from dual union all
select 'ESTIMATED_EFFORT_IN_HOURS' cname, wwv_flow_lang.system_message('ESTIMATED_EFFORT_IN_HOURS') cmessage from dual union all
select 'SECURITY_STATUS' cname, wwv_flow_lang.system_message('SECURITY_STATUS') cmessage from dual union all
select 'ACCESSIBILITY_STATUS' cname, wwv_flow_lang.system_message('ACCESSIBILITY_STATUS') cmessage from dual union all
select 'GLOBALIZATION_STATUS' cname, wwv_flow_lang.system_message('GLOBALIZATION_STATUS') cmessage from dual union all
select 'USER_INTERFACE_STATUS' cname, wwv_flow_lang.system_message('USER_INTERFACE_STATUS') cmessage from dual
/

