CREATE VIEW WWV_FLOW_JAVASCRIPT_EVENTS AS
  select d, r, g
  from ( select 1            as order_by,
                '1'          as order_by2,
                wwv_flow_lang.system_message('EVENT.BROWSER.' || name) as d,
                name         as r,
                wwv_flow_lang.system_message('EVENT.BROWSER') as g
           from wwv_flow_standard_events
          where event_type = 'BROWSER'
          union all
        select  2            as order_by,
                '1'          as order_by2,
                display_name as d,
                name         as r,
                wwv_flow_lang.system_message('EVENT.FRAMEWORK') as g
           from wwv_flow_standard_events
          where event_type = 'APEX'
          union all
         select 3               as order_by,
                p.display_name  as order_by2,
                e.display_name || ' [' || p.display_name || ']'             as d,
                p.name_with_prefix || '|' || p.plugin_type || '|' || e.name as r,
                wwv_flow_lang.system_message('EVENT.COMPONENT')             as g
           from ( select id,
                         display_name,
                         plugin_type,
                         name_with_prefix
                    from wwv_flow_native_plugins p
                   union all
                  select id,
                         display_name,
                         plugin_type,
                         'PLUGIN_' || name
                    from wwv_flow_plugins
                   where flow_id           = (select nv('FB_FLOW_ID') from dual)
                     and security_group_id = (select nv('FLOW_SECURITY_GROUP_ID') sgid from dual)
                ) p,
                wwv_flow_plugin_events e
          where e.plugin_id = p.id
          order by order_by, order_by2, d)
/

