CREATE TRIGGER WWV_FLOW_WS_WEBSHEET_ATTR_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_WS_WEBSHEET_ATTR
  FOR EACH ROW
  begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    if inserting then
        :new.created_on := sysdate;
        :new.created_by := nvl(wwv_flow.g_user,user);
        if :new.websheet_owner is null then
           :new.websheet_owner := nvl(wwv_flow.g_user,user);
        end if;
    end if;

    -- populate websheet alias
    if :new.websheet_alias is null then
        select wwv_seq.nextval
        into :new.websheet_alias
        from dual;
    else
        :new.websheet_alias := upper(:new.websheet_alias);
    end if;

    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;

    :new.updated_on := sysdate;
    :new.updated_by := nvl(wwv_flow.g_user,user);

    -- cascade update
    if not wwv_flow.g_import_in_progress then
        update wwv_flow_ws_applications set
            updated_on = sysdate,
            updated_by = wwv_flow.g_user
        where
            id = :new.ws_app_id and
            security_group_id = :new.security_group_id;
    end if;
end;
/

