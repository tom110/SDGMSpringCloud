CREATE VIEW WWV_FLOW_HOURS_12 AS
  select i from wwv_flow_dual100 where i < 13
/

