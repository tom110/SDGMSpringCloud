CREATE VIEW WWV_MULTI_COMPONENT_EXPORT AS
  select c.flow_id as flow_id,
       seq_id,
       component_type,
       case component_type
         when 'PAGE TEMPLATE'          then (select name from wwv_flow_templates where id = c.component_id and flow_id = c.flow_id)
         when 'LIST'                   then (select name from wwv_flow_lists where id = c.component_id and flow_id = c.flow_id)
         when 'BREADCRUMB'             then (select name from wwv_flow_menus where id = c.component_id and flow_id = c.flow_id)
         when 'BUTTON TEMPLATE'        then (select template_name from wwv_flow_button_templates where id = c.component_id and flow_id = c.flow_id)
         when 'REGION TEMPLATE'        then (select page_plug_template_name from wwv_flow_page_plug_templates where id = c.component_id and flow_id = c.flow_id)
         when 'LIST TEMPLATE'          then (select list_template_name from wwv_flow_list_templates where id = c.component_id and flow_id = c.flow_id)
         when 'REPORT TEMPLATE'        then (select row_template_name from wwv_flow_row_templates where id = c.component_id and flow_id = c.flow_id)
         when 'LABEL TEMPLATE'         then (select template_name from wwv_flow_field_templates where id = c.component_id and flow_id = c.flow_id)
         when 'BREADCRUMB TEMPLATE'    then (select name from wwv_flow_menu_templates where id = c.component_id and flow_id = c.flow_id)
         when 'CALENDAR TEMPLATE'      then (select name from wwv_flow_cal_templates where id = c.component_id and flow_id = c.flow_id)
         when 'SHORTCUTS'              then (select shortcut_name from wwv_flow_shortcuts where id = c.component_id and flow_id = c.flow_id)
         when 'POPUP LOV TEMPLATE'     then (select page_title from wwv_flow_popup_lov_template where flow_id = c.flow_id)
         when 'PAGE'                   then (select id||'. '||name n from wwv_flow_steps where id = c.component_id and flow_id = c.flow_id)
         when 'TAB'                    then (select tab_set||': '||tab_name||' ('||tab_text||')' n from wwv_flow_tabs where id = c.component_id and flow_id = c.flow_id)
         when 'PARENT TAB'             then (select tab_set||': '||tab_name||' ('||tab_text||')' n from wwv_flow_toplevel_tabs where id = c.component_id and flow_id = c.flow_id)
         when 'LOV'                    then (select lov_name n from wwv_flow_lists_of_values$ where id = c.component_id and flow_id = c.flow_id)
         when 'NAVBAR'                 then (select icon_sequence||'. '||icon_image_alt||' ('||icon_image||')' n from wwv_flow_icon_bar where id = c.component_id and flow_id = c.flow_id)
         when 'SECURITY SCHEME'        then (select name n from wwv_flow_security_schemes where id = c.component_id and flow_id = c.flow_id)
         when 'TREE'                   then (select tree_name n from wwv_flow_trees where id = c.component_id and flow_id = c.flow_id)
         when 'PAGE GROUP'             then (select group_name n from wwv_flow_page_groups where id = c.component_id and flow_id = c.flow_id)
         when 'APP ITEM'               then (select name from wwv_flow_items where id = c.component_id and flow_id = c.flow_id)
         when 'APP PROCESS'            then (select process_name n from wwv_flow_processing where id = c.component_id and flow_id = c.flow_id)
         when 'APP COMPUTATION'        then (select computation_sequence||'. '||computation_item n from wwv_flow_computations where id = c.component_id and flow_id = c.flow_id)
         when 'BREADCRUMB ENTRY'       then (select (select name from wwv_flow_menus where id = be.menu_id)||': '||short_name||' ('||page_id||')' n from wwv_flow_menu_options be where id = c.component_id and flow_id = c.flow_id)
         when 'SHARED QUERY'           then (select name from wwv_flow_shared_queries where id = c.component_id and flow_id = c.flow_id)
         when 'REPORT LAYOUT'          then (select report_layout_name from wwv_flow_report_layouts where id = c.component_id and flow_id = c.flow_id)
         when 'WEB SERVICE'            then (select name from wwv_flow_shared_web_services where id = c.component_id and flow_id = c.flow_id)
         when 'AUTH SETUP'             then (select name from wwv_flow_custom_auth_setups where id = c.component_id and flow_id = c.flow_id)
         when 'BUILD OPTION STATUS'    then (select patch_name from wwv_flow_patches where id = c.component_id and flow_id = c.flow_id)
         when 'BUILD OPTION'           then (select patch_name from wwv_flow_patches where id = c.component_id and flow_id = c.flow_id)
         when 'APPLICATION ATTRIBUTES' then
             case c.component_id
               when  1 then wwv_flow_lang.system_message('F4000.P4656.DEFAULT_PAGE_TEMPLATE')
               when  2 then wwv_flow_lang.system_message('LOGO')
               when  3 then wwv_flow_lang.system_message('F4000_P811_LOGOUT_URL')
               when  4 then wwv_flow_lang.system_message('LAYOUT.T_ALT_GLOBAL_NOTIFICATION')
               when  5 then wwv_flow_lang.system_message('AUTHENTICATION')
               when  6 then wwv_flow_lang.system_message('HOME_LINK')
               when  7 then wwv_flow_lang.system_message('IMAGE_PREFIX')
               when  8 then wwv_flow_lang.system_message('LOGGING')
               when  9 then wwv_flow_lang.system_message('APPLICATION_OWNER')
               when 10 then wwv_flow_lang.system_message('STATIC_SUBSTITUTION_STRINGS')
               when 11 then wwv_flow_lang.system_message('APPLICATION_STATUS')
               when 12 then wwv_flow_lang.system_message('ENABLE_DEBUGGING')
               when 13 then wwv_flow_lang.system_message('APPLICATION_NAME')
               when 14 then wwv_flow_lang.system_message('APPLICATION_ALIAS')
               when 15 then wwv_flow_lang.system_message('EXACT_SUBS')
               when 16 then wwv_flow_lang.system_message('SECURITY_SCHEME')
               when 17 then wwv_flow_lang.system_message('PROXY_SERVER')
               when 18 then wwv_flow_lang.system_message('PAGE_PROTECTION')
               when 19 then wwv_flow_lang.system_message('VPD')
             end
         end           as component_name,
       c.component_id
  from ( select to_number(c003) as flow_id,
                seq_id,
                c001            as component_type,
                to_number(c002) as component_id
           from wwv_flow_collections
          where collection_name = 'MULTI_COMPONENT_EXPORT' ) c
/

