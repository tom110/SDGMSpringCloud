CREATE VIEW APEX_WORKSPACES AS
  select
    w.short_name                                        workspace,
    w.source_identifier                                 source_identifier,
    --w.FIRST_SCHEMA_PROVISIONED                          first_schema_provisioned,
    --
    count(distinct s.schema)                            schemas,
    max(w.LAST_LOGIN)                                   last_purged_session,
    --
    nvl(ALLOW_APP_BUILDING_YN,'Y')                      ALLOW_APP_BUILDING_YN,
    nvl(ALLOW_SQL_WORKSHOP_YN,'Y')                      ALLOW_SQL_WORKSHOP_YN,
    nvl(ALLOW_WEBSHEET_DEV_YN,'Y')                      ALLOW_WEBSHEET_DEV_YN,
    nvl(ALLOW_TEAM_DEVELOPMENT_YN,'Y')                  ALLOW_TEAM_DEVELOPMENT_YN,
    nvl(ALLOW_TO_BE_PURGED_YN,'Y')                      ALLOW_TO_BE_PURGED_YN,
    --
    (select count(*)
     from wwv_flow_sessions$
     where security_group_id =
           w.PROVISIONING_COMPANY_ID)                   sessions,
    --
    (select count(*)
     from   wwv_flows
     where  security_group_id =
            w.PROVISIONING_COMPANY_ID)                  applications,
    --
    (select count(*)
     from   wwv_flow_steps
     where  security_group_id =
            w.PROVISIONING_COMPANY_ID)                  application_pages,
    --
    (select count(*)
     from   wwv_flow_fnd_user
     where  security_group_id =
            w.PROVISIONING_COMPANY_ID)                  apex_users,
    --
    (select count(*)
     from wwv_flow_developers d, wwv_flow_fnd_user u
     where (instr(nvl(d.developer_role,'x'),'EDIT') > 0 or
            instr(nvl(d.developer_role,'x'),'ADMIN') > 0 ) and
           d.security_group_id = w.PROVISIONING_COMPANY_ID and
           u.security_group_id = w.PROVISIONING_COMPANY_ID and
           d.userid = u.user_name)
                                                        apex_developers,
    --
    (select count(*)
     from   wwv_flow_developers d, wwv_flow_fnd_user u
     where  instr(nvl(d.developer_role,'x'),'ADMIN') > 0  and
           d.security_group_id = w.PROVISIONING_COMPANY_ID and
           u.security_group_id = w.PROVISIONING_COMPANY_ID and
           d.userid = u.user_name)
                                                        apex_workspace_administrators,
    --
    (select count(*)
     from    WWV_FLOW_FILE_OBJECTS$
     where   security_group_id =
            w.PROVISIONING_COMPANY_ID and
            to_char(deleted_as_of,
            'MM.DD.YYYY') = '01.01.0001')               files,
    --
    (select count(*)
     from    WWV_FLOW_FILE_OBJECTS$
     where   security_group_id =
            w.PROVISIONING_COMPANY_ID and
            FILE_TYPE = 'SCRIPT' and
            to_char(deleted_as_of,
            'MM.DD.YYYY') = '01.01.0001')               sql_scripts,
    --
    (select count(*)
     from   WWV_FLOW_MESSAGES$
     where  security_group_id =
            w.PROVISIONING_COMPANY_ID)                  translation_messages,
    --
    (select sum(doc_size)
     from    WWV_FLOW_FILE_OBJECTS$
     where   security_group_id =
            w.PROVISIONING_COMPANY_ID)                  file_storage,
    --
    nvl(
        (select max(time_stamp) d
        from wwv_flow_activity_log l
        where l.security_group_id = w.PROVISIONING_COMPANY_ID and l.time_stamp > sysdate - 1),
        (select max(log_day) d
        from wwv_flow_log_history h
        where h.workspace_id = w.PROVISIONING_COMPANY_ID)
        ) last_logged_page_view,
    --
     (select count(*)
     from   wwv_flow_activity_log l
     where  security_group_id =
            w.PROVISIONING_COMPANY_ID and
            l.TIME_STAMP > sysdate - 14)                page_views,
     --
     w.PROVISIONING_COMPANY_ID                          workspace_id
from
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = w.PROVISIONING_COMPANY_ID) and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      w.PROVISIONING_COMPANY_ID != 0
group by  w.PROVISIONING_COMPANY_ID, w.short_name, w.source_identifier, w.FIRST_SCHEMA_PROVISIONED,
          w.ALLOW_APP_BUILDING_YN,
          w.ALLOW_SQL_WORKSHOP_YN,
          w.ALLOW_WEBSHEET_DEV_YN,
          w.ALLOW_TEAM_DEVELOPMENT_YN,
          w.ALLOW_TO_BE_PURGED_YN
/

