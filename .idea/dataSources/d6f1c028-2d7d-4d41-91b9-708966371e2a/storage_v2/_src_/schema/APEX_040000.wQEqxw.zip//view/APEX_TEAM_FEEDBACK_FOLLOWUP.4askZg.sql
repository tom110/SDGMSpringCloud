CREATE VIEW APEX_TEAM_FEEDBACK_FOLLOWUP AS
  select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
    f.ID                        followup_id,
    f.feedback_id               feedback_id,
    --
    f.follow_up,
    f.email,
    --
    f.CREATED_BY,
    f.CREATED_ON,
    f.UPDATED_BY,
    f.UPDATED_ON
from
    wwv_flow_feedback_followup f,
    wwv_flow_feedback fe,
    wwv_flow_companies w
where
    f.feedback_id = fe.id and
    fe.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

