CREATE VIEW APEX_APPLICATION_PAGE_IR_COND AS
  select
w.short_name          workspace,
f.id                  application_id,
f.name                application_name,
r.page_id             page_id,
r.worksheet_id        interactive_report_id,
r.id                  report_id,
r.application_user    application_user,
r.name                report_name,
c.id                  condition_id,
c.name                condition_name,
decode(c.condition_type,'FILTER','Filter','HIGHLIGHT','Highlight','SEARCH','Search',c.condition_type)
                      condition_type,
decode(c.allow_delete,'Y','Yes','N','No',c.allow_delete)
                      condition_allow_delete,
c.time_zone           time_zone,
-- filter expression
c.column_name         condition_column_name,
c.operator            condition_operator,
c.expr_type           condition_expr_type,
c.expr                condition_expression,
c.expr2               condition_expression2,
c.condition_sql       condition_sql,
c.condition_display   condition_display,
-- enabled?
decode(c.enabled,'Y','Yes','N','No',c.enabled)
                      condition_enabled,
-- highlighting settings
c.highlight_sequence  ,
c.row_bg_color        highlight_row_color,
c.row_font_color      highlight_row_font_color,
c.column_bg_color     highlight_cell_color,
c.column_font_color   highlight_cell_font_color,
-- audit
--
c.created_on        ,
c.created_by        ,
c.updated_on        last_updated_on,
c.updated_by        last_updated_by
--
from wwv_flow_worksheet_conditions c,
     wwv_flow_worksheet_rpts r,
     wwv_flow_worksheets ws,
     wwv_flows f,
     wwv_flow_companies w,
     wwv_flow_company_schemas s,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      f.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.schema = f.owner and
      f.security_group_id = r.security_group_id and
      f.id = ws.flow_id and ws.id = r.worksheet_id and r.id = c.report_id and
      (d.sgid != 0 or nvl(f.BUILD_STATUS,'x') != 'RUN_ONLY') and
      w.PROVISIONING_COMPANY_ID != 0
/

