CREATE TRIGGER WWV_FLOW_STANDARD_JS_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_STANDARD_JS
  FOR EACH ROW
  begin
    if inserting and :new.id is null then
         :new.id := wwv_flow_id.next_val;
    end if;
end;
/

