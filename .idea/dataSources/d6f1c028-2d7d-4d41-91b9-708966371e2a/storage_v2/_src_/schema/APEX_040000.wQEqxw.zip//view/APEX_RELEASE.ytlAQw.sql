CREATE VIEW APEX_RELEASE AS
  select (select wwv_flows_release from dual) version_no,
       (select wwv_flows_version from dual) api_compatibility,
       (select wwv_flow_platform.get_preference('APEX_3_0_1_PATCH') from dual) patch_applied
  from dual
/

