CREATE TRIGGER WWV_FLOW_EVENTS_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_EVENTS
  FOR EACH ROW
  begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    if :new.security_group_id is null then
        :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;

    if inserting and :new.created_by is null then
       :new.created_by := nvl(wwv_flow.g_user,USER);
    end if;
    if inserting and :new.created_on is null then
       :new.created_on := sysdate;
    end if;
    if inserting and :new.updated_by is null then
       :new.updated_by :=nvl(wwv_flow.g_user,user);
    end if;
    if inserting and :new.updated_on is null then
       :new.updated_on := sysdate;
    end if;
    if inserting or updating then
       :new.updated_by := nvl(wwv_flow.g_user,user);
       :new.updated_on := sysdate;
    end if;

    if inserting or updating then
       :new.EVENT_OWNER := trim(lower(:new.EVENT_OWNER));

       if :new.event_id is null then
           select nvl(max(event_id),0) + 1
           into:new.event_id
           from wwv_flow_events
           where security_group_id = nvl(wwv_flow_security.g_security_group_id,0);
       end if;
    end if;

    --
    -- TAG
    --
    begin
    wwv_flow_team.wwv_flow_team_tag_sync (
        p_component_type    => 'MILESTONE',
        p_component_id      => :new.id,
        p_new_tags          => :new.TAGS,
        p_security_group_id => :new.security_group_id);
    exception when others then
        null;
    end;
end wwv_flow_events_t1;
/

