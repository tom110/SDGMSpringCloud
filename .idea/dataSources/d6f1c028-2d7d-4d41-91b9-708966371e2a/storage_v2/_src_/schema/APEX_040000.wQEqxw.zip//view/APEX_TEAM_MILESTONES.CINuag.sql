CREATE VIEW APEX_TEAM_MILESTONES AS
  select
    w.PROVISIONING_COMPANY_ID   workspace_id,
    w.short_name                workspace_name,
    --
	m.ID                        milestone_id,
	m.EVENT_NAME                milestone,
	m.EVENT_OWNER               milestone_owner,
	m.EVENT_DATE                milestone_date,
	m.EVENT_TYPE                milestone_type,
	m.RELEASE                   release,
	m.EVENT_DESC                milestone_description,
	m.TAGS                      tags,
	--
	m.CREATED_BY,
	m.CREATED_ON,
	m.UPDATED_BY,
	m.UPDATED_ON,
	m.EVENT_ID                  friendly_milestone_id,
	m.SELECTABLE_FROM_FEATURES_YN
from
    WWV_FLOW_EVENTS m,
    wwv_flow_companies w
where
    m.security_group_id = w.PROVISIONING_COMPANY_ID and
    w.PROVISIONING_COMPANY_ID in (
       select security_group_id
       from   wwv_flow_company_schemas s,
              (select nvl(v('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
       where  (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000') or d.sgid = s.security_group_id) ) and
    (user in ('SYS', 'SYSTEM', 'APEX_040000') or w.PROVISIONING_COMPANY_ID != 10)
/

