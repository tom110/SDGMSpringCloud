CREATE VIEW APEX_UI_DEFAULTS_ATTR_DICT AS
  select
    w.short_name workspace,
    --
    syn.syn_name column_name,
    case when c.column_name != syn.syn_name
         then c.column_name
         end synonym_of,
    c.label,
    c.help_text,
    c.format_mask,
    c.default_value,
    c.form_format_mask,
    c.form_display_width,
    c.form_display_height,
    c.form_data_type,
    c.report_format_mask,
    c.report_col_alignment,
    c.created_by,
    c.created_on,
    c.last_updated_by,
    c.last_updated_on
from wwv_flow_hnt_column_dict c,
     wwv_flow_hnt_col_dict_syn syn,
     wwv_flow_company_schemas s,
     wwv_flow_companies w,
     (select nvl(nv('FLOW_SECURITY_GROUP_ID'),0) sgid from dual) d
where (s.schema = user or user in ('SYS','SYSTEM', 'APEX_040000')  or d.sgid = s.security_group_id) and
      c.security_group_id = w.PROVISIONING_COMPANY_ID and
      c.column_id = syn.column_id and
      syn.security_group_id = w.PROVISIONING_COMPANY_ID and
      s.security_group_id = w.PROVISIONING_COMPANY_ID and
      d.sgid != 0 and
      w.PROVISIONING_COMPANY_ID != 0
/

