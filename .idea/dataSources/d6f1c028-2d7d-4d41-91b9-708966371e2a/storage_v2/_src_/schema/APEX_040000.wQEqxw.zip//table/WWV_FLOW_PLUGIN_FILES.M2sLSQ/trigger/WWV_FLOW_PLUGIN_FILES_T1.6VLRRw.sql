CREATE TRIGGER WWV_FLOW_PLUGIN_FILES_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_PLUGIN_FILES
  FOR EACH ROW
  begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;

    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;

    --
    -- created / last updated
    -- Note: always set change attributes so that the caching of files works
    if inserting then
        :new.created_on := sysdate;
        :new.created_by := wwv_flow.g_user;
    end if;
    --
    :new.last_updated_on := sysdate;
    :new.last_updated_by := wwv_flow.g_user;
    --
    if not wwv_flow.g_import_in_progress then
        update wwv_flow_plugins
           set last_updated_on = sysdate,
               last_updated_by = wwv_flow.g_user
         where id                = :new.plugin_id
           and security_group_id = :new.security_group_id;
    end if;
end;
/

