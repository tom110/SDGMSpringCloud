CREATE TRIGGER WWV_FLOW_TASKS_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_TASKS
  FOR EACH ROW
  begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;
    if :new.security_group_id is null then
        :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;

    if inserting and :new.created_by is null then
       :new.created_by := nvl(wwv_flow.g_user,USER);
    end if;
    if inserting and :new.created_on is null then
       :new.created_on := sysdate;
    end if;
    if inserting and :new.updated_by is null then
       :new.updated_by :=nvl(wwv_flow.g_user,user);
    end if;
    if inserting and :new.updated_on is null then
       :new.updated_on := sysdate;
    end if;
    if inserting or updating then
       :new.updated_by := nvl(wwv_flow.g_user,user);
       :new.updated_on := sysdate;
    end if;
    --
    -- start date and complete date
    --
    if inserting or updating then
        if :new.task_status is null then
           :new.task_status := 0;
        end if;

        if :new.task_status = 100 and :new.date_completed is null then
           :new.date_completed := sysdate;
        end if;
        if :new.date_completed is not null and :new.task_status < 100 then
           :new.task_status := 100;
        end if;
    end if;

    --
    -- owner
    --
    if inserting or updating then
        :new.assigned_to := trim(lower(:new.assigned_to));
        :new.contributor := trim(lower(:new.contributor));
    end if;

    --
    -- TAGS
    --
    wwv_flow_team.wwv_flow_team_tag_sync (
        p_component_type    => 'TODO',
        p_component_id      => :new.id,
        p_new_tags          => :new.TASK_TAGS,
        p_security_group_id => :new.security_group_id);

    --
    -- task number
    --
    if inserting or updating then
        if :new.FRIENDLY_ID is null then
           for c1 in (
                   select nvl(max(FRIENDLY_ID),0) + 1 x
                   from   wwv_flow_tasks
                   where  security_group_id = wwv_flow_security.g_security_group_id)
                   loop
                   :new.friendly_id := c1.x;
           end loop;
        end if;
    end if;
end;
/

