CREATE TRIGGER WWV_FLOW_WS_APPLICATIONS_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_WS_APPLICATIONS
  FOR EACH ROW
  begin
    --
    -- maintain pk and timestamps
    --
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;

    if inserting then
        :new.created_on := sysdate;
        :new.created_by := nvl(wwv_flow.g_user,user);
        :new.updated_on := sysdate;
        :new.updated_by := nvl(wwv_flow.g_user,user);
    elsif updating then
        :new.updated_on := sysdate;
        :new.updated_by := nvl(wwv_flow.g_user,user);
    end if;
    --
    if :new.allow_public_access_yn is null then
        :new.allow_public_access_yn := 'N';
    end if;

    --
    -- set owner
    --
    if :new.owner is null then
        :new.owner := :new.created_by;
    end if;
    --
    -- set status
    --
    if :new.status is null then
        :new.status := 'AVAILABLE';
    end if;

    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;
end;
/

