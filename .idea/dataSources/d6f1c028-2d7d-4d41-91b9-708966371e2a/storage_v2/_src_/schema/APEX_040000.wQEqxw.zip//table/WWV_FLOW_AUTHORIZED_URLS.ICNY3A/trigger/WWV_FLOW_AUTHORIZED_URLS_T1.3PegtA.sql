CREATE TRIGGER WWV_FLOW_AUTHORIZED_URLS_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_AUTHORIZED_URLS
  FOR EACH ROW
  begin
    -- normalize the case of the entire URL
    :new.url := trim(lower(:new.url));
    if :new.url is not null then
        :new.url_md5 := utl_raw.cast_to_raw(dbms_obfuscation_toolkit.md5( input_string => :new.url ));
    end if;

    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;

    if inserting then
        :new.created_on := sysdate;
        :new.created_by := nvl(wwv_flow.g_user,user);
        :new.last_updated_on := :new.created_on;
    end if;

    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;

    --
    -- last updated
    --
    if updating then
        :new.last_updated_on := sysdate;
    end if;
    :new.last_updated_by := nvl(wwv_flow.g_user,user);
end;
/

