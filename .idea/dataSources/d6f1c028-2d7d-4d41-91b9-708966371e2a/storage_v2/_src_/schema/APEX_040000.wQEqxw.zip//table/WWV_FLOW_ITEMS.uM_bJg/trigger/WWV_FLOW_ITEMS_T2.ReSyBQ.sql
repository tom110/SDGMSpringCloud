CREATE TRIGGER WWV_FLOW_ITEMS_T2
  BEFORE DELETE
  ON WWV_FLOW_ITEMS
  FOR EACH ROW
  begin
    --
    -- cascade delete flow and step computations referencing item
    --
    if nvl(wwv_flow_api.g_mode,'x') != 'REPLACE' then
        begin
            delete wwv_flow_computations
                where upper(computation_item) = upper(:old.name)
                and flow_id = :old.flow_id
                and security_group_id = :old.security_group_id;
            delete wwv_flow_step_computations
                where upper(computation_item) = upper(:old.name)
                and flow_id = :old.flow_id
                and security_group_id = :old.security_group_id;
        exception when others then null;
        end;
    end if;
end;
/

