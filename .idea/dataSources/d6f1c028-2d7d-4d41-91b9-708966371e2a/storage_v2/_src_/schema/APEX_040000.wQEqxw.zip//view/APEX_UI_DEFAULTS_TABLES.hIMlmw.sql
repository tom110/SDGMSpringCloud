CREATE VIEW APEX_UI_DEFAULTS_TABLES AS
  select schema,
       table_name,
       form_region_title,
       report_region_title,
       created_by,
       created_on,
       last_updated_by,
       last_updated_on
  from wwv_flow_hnt_table_info
 where schema = user
/

