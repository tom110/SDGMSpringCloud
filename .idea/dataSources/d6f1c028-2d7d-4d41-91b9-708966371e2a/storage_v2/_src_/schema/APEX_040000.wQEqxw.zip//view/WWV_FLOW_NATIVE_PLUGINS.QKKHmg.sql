CREATE VIEW WWV_FLOW_NATIVE_PLUGINS AS
  select id,
       plugin_type,
       name,
       'NATIVE_'||name as name_with_prefix,
       display_name,
       category,
       standard_attributes,
       sql_min_column_count,
       sql_max_column_count,
       sql_examples
  from wwv_flow_plugins
 where flow_id           = nvl((select wwv_flow_lang.get_translated_application_id(4411) from dual), 4411)
   and security_group_id = 10
/

