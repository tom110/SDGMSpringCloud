CREATE TRIGGER WWV_FLOW_PLUGINS_T1
  BEFORE INSERT OR UPDATE
  ON WWV_FLOW_PLUGINS
  FOR EACH ROW
  begin
    if inserting and :new.id is null then
        :new.id := wwv_flow_id.next_val;
    end if;

    --
    -- set name
    --
    :new.name := upper(:new.name);

    --
    -- vpd
    --
    if :new.security_group_id is null then
       :new.security_group_id := nvl(wwv_flow_security.g_security_group_id,0);
    end if;

    --
    -- created / last updated
    --
    if not wwv_flow.g_import_in_progress then
        if inserting then
            :new.created_on := sysdate;
            :new.created_by := wwv_flow.g_user;
        end if;
        --
        :new.last_updated_on := sysdate;
        :new.last_updated_by := wwv_flow.g_user;
        --
        update wwv_flows
           set last_updated_on = sysdate,
               last_updated_by = wwv_flow.g_user
         where id                = :new.flow_id
           and security_group_id = :new.security_group_id;
    end if;
end;
/

