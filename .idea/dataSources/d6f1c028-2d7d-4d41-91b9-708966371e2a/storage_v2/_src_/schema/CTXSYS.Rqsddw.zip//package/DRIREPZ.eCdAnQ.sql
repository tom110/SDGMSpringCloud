CREATE package drirepz as

/*--------------------------- index_size --------------------------------*/

procedure index_size(
  index_name    in varchar2,
  report        in out nocopy clob,
  part_name     in varchar2 default null,
  report_format in varchar2 DEFAULT 'TEXT'
);

end drirepz;
/

