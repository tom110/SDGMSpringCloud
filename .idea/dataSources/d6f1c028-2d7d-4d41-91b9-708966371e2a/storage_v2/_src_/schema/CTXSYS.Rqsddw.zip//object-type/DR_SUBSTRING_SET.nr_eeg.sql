CREATE type dr$substring_set as table of dr$substring;
/

