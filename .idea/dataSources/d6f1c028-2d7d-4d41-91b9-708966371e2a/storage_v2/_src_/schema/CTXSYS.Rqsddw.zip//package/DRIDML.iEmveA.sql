CREATE package dridml
is

  LOCK_WAIT       constant number  := null;
  LOCK_NOWAIT     constant number  := 0;
  IGNORE_ERRORS   constant boolean := TRUE;

/*--------------------------- deregister --------------------------------*/
/*
  NAME
    DEREGISTER(cid) - deregister the given column with DML queue,

  DESCRIPTION
    This procedure discontinues queueing of updates to the DML
    queue.   It also flushes any pending requests, and waits for any
    in-progress requests to complete
  ARGUMENTS
    CID		- the column id to register
    unlock      - unlock DML afterwards?
    zap_online_pending -- clear dr$online_pending
*/
procedure DEREGISTER(cid number, unlock in boolean default TRUE,
                     part_id number default 0,
                     part_name in varchar2 default null,
                     zap_online_pending in boolean default TRUE);

/*------------------------------ lock_dml --------------------------------*/
/*
  NAME
    lock_dml

  DESCRIPTION
     lock dml for a column

  ARGUMENTS
     cid        -- cid to lock
     timeout    -- if non-null, timeout
     pid        -- partition id

  RETURNS
     0 on success, 1 on timeout

  NOTES
     This does not block out incoming DML reindex requests.
*/
function lock_dml_ret(
  cid        in number,
  pid        in number,
  timeout    in number
) return number;

procedure lock_dml(
  cid        in number,
  pid        in number,
  timeout    in number
);

/*------------------------- lock_dml_all_part ----------------------------*/
/* NOTE: gets multiple locks.  If fails, it's up to calling procedure to  */
/* release any locks it may have gotten                                   */
procedure lock_dml_all_part(
  cid        in number
);

/*----------------------------- unlock_dml ------------------------------*/
/*
  NAME
     UNLOCK_DML

  DESCRIPTION
     Unlock the DML queue

  ARGUMENTS
     ignore_errors	- don't flag any errors
*/
procedure unlock_dml(
  ignore_errors in boolean default false
);

/*------------------------ unlock_dml_all_part ---------------------------*/

procedure unlock_dml_all_part(
  ignore_errors in boolean default false
);

/* 5364449: Removed get_dml */

/*--------------------------- ClearOnlinePending ------------------------*/

procedure ClearOnlinePending(
  p_idxid in number,
  index_partition in varchar2 default NULL
);

/*--------------------------- ExchangePending ---------------------------*/
/* exchange all rows in dr$pending, dr$waiting, etc. for exchange partition */

procedure ExchangePending(
  p_idxid1 in number,
  p_ixpid1 in number,
  p_idxid2 in number
);

/*------------------------- delete_dup_waiting ----------------------------*/
/* eliminate duplicate dr$waiting rows */

procedure delete_dup_waiting(cid in number, pid in number);

/*------------------------- open_waiting_cur ----------------------------*/
/* open cursor on dr$waiting */

procedure open_waiting_cur(cid in number, pid in number);

/*------------------------- fetch_waiting_cur ----------------------------*/
/* fetch row from waiting cursor */

function fetch_waiting_cur(rid out rowid, wrid out urowid) return number;

/*------------------------- insert_pending -------------------------------*/
/* insert a row into dr$pending */

procedure insert_pending(
  cid  in number,
  pid  in number,
  rid  in rowid,
  wrid in urowid default null
);

/*-------------------------- DeletePending -------------------------*/

procedure DeletePending (
  p_idxid  in number,
  p_ixpid  in number,
  p_rid    in rowid
);

/*-------------------------- DeletePendingArr ----------------------*/

procedure DeletePendingArr (
  p_idxid  in number,
  p_ixpid  in number,
  p_rid    in dr_def.rowid_tab
);

/*-------------------------- SetLockFailed -------------------------*/

procedure SetLockFailed (
  p_idxid  in number,
  p_ixpid  in number,
  p_rid    in rowid
);

/*-------------------------- HasPending ----------------------------*/

function HasPending (
  p_idxid  in number,
  p_ixpid  in number
) return boolean;

/*-------------------------- CleanDelete ---------------------------*/

procedure CleanDelete (
  p_idxid  in number,
  p_ixpid  in number
);

/*-------------------------- PopulatePendingRowid ---------------------------*/

procedure PopulatePendingRowid (
  p_idxid in number,
  p_ixpid in number,
  p_rowid in varchar2
);

/*-------------------------- lock_autosync_ret --------------------------*/
function lock_autosync_ret(
  cid        in number,
  pid        in number,
  timeout    in number
) return number;

/*---------------------------- lock_autosync ----------------------------*/
procedure lock_autosync(
  cid        in number,
  pid        in number,
  timeout    in number
);

/*--------------------------- unlock_autosync ---------------------------*/
procedure unlock_autosync(
  ignore_errors in boolean default false
);

end dridml;
/

