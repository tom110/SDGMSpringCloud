CREATE type          SYS_PLSQL_13555_305_1 as table of "CTXSYS"."SYS_PLSQL_13555_290_1";
/

