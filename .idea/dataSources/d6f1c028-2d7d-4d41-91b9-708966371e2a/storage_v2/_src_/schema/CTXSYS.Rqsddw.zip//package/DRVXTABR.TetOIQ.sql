CREATE package drvxtabr authid current_user as

/* ====================================================================== */
/* ====================================================================== */
/*                             CTXRULE                                    */
/* ====================================================================== */
/* ====================================================================== */

/*----------------------- create_tables --------------------------*/

PROCEDURE create_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- create_indexes  ------------------------*/

PROCEDURE create_indexes(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- drop_tables  ---------------------------*/

PROCEDURE drop_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- trunc_tables  ---------------------------*/

PROCEDURE trunc_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number
);

/*----------------------- rename_tables  ---------------------------*/

PROCEDURE rename_tables(
  idx_owner in varchar2,
  idx_name  in varchar2,
  idxid     in number,
  new_name  in varchar2,
  has_idx   in boolean
);

end drvxtabr;
/

