CREATE type          SYS_PLSQL_13555_30_1 as table of "CTXSYS"."SYS_PLSQL_13555_12_1";
/

