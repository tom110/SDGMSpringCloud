CREATE type          SYS_PLSQL_13555_92_1 as table of "CTXSYS"."SYS_PLSQL_13555_74_1";
/

