CREATE type dr$mapdoc_set_t as table of dr$mapdoc_t;
/

