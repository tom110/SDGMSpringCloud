CREATE package drientl AUTHID current_user as

/*------------------------- prep_dict -----------------------------------*/
/*
  NAME
    prep_dict

  DESCRIPTION
    prepare user dictionary for insertion
*/

FUNCTION prep_dict(
  p_policy IN VARCHAR2,
  locking  IN NUMBER
) return binary_integer;

/*------------------------- add_dict_entry-------------------------------*/
/*
  NAME
    add_dict_entry

  DESCRIPTION
    add a dictionary entry to the user dictionary

*/

PROCEDURE add_dict_entry(
  p_pid           IN NUMBER,
  p_eid           IN NUMBER,
  p_lang          IN VARCHAR2,
  p_mention       IN VARCHAR2,
  p_type          IN VARCHAR2,
  p_normid        IN NUMBER,
  p_altcnt        IN NUMBER
);

/*--------------------------- chkdupdict ------------------------------------*/
/*
  NAME
    chkdupdict
  DESCRIPTION
    Check whether a dictionary has already been loaded                       */

PROCEDURE chkdupdict;

/*----------------------- close_dict ----------------------------------*/
/*
  NAME
    close_dict

  DESCRIPTION
    run any closing procedures
*/

PROCEDURE close_dict;


/*--------------------------- drop_dict -------------------------------------*/
/*
  NAME
    drop_dict

  DESCRIPTION
    drop a user-defined dictionary
*/

PROCEDURE drop_dict;

end drientl;
/

