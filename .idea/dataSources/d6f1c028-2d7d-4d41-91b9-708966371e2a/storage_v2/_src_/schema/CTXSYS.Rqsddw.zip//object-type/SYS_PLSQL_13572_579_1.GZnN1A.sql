CREATE type          SYS_PLSQL_13572_579_1 as table of "CTXSYS"."SYS_PLSQL_13572_559_1";
/

