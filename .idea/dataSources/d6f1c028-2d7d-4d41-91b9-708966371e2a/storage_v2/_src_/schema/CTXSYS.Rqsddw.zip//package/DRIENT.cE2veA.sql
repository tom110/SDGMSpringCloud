CREATE package drient as

/*--------------------------- compile ---------------------------------------*/

PROCEDURE compile(
  idx            IN dr_def.idx_rec,
  compile_choice IN NUMBER,
  locking        IN NUMBER
);

/*--------------------------- chkextpol -------------------------------------*/
/* chkextpol - Check that policy is an extraction policy                     */
FUNCTION chkextpol(
  idx        IN dr_def.idx_rec
) return BOOLEAN;

end drient;
/

