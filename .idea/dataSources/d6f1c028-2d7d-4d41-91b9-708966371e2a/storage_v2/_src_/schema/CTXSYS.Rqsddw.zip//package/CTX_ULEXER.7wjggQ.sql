CREATE PACKAGE ctx_ulexer AS

  -- index-by table to specify offset of those characters in the query
  -- word which are to be treated as wildcard characters
  TYPE wildcard_tab IS TABLE OF NUMBER INDEX BY BINARY_INTEGER;

END ctx_ulexer;
/

