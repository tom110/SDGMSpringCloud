CREATE type          SYS_PLSQL_13555_DUMMY_1 as table of number;
/

