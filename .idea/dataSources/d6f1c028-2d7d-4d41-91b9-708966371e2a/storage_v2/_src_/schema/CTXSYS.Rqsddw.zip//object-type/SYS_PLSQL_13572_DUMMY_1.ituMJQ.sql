CREATE type          SYS_PLSQL_13572_DUMMY_1 as table of number;
/

